package clases;
import javax.swing.*;
import java.awt.*;
import java.util.jar.JarFile;
//public void cambiarPanel(JPanel nuevoPanel) {
//    if (panelActual != null) {
//        remove(panelActual); // Eliminamos el anterior
//    }
//
//    panelActual = nuevoPanel; // Asignamos el nuevo panel
//    panelActual.setBounds(0, 0, getWidth(), getHeight()); // Aseguramos tamaño
//    add(panelActual);
//
//    revalidate();
//    repaint();
//}

public class Frame extends JFrame {
    ImageIcon icono = new ImageIcon(getClass().getResource("./../imagenes/EpiFotoBuena.jpg"));
    static Frame frame;

    public Frame(){
        frame = this;
        setVisible(true);
        setSize(getDimension());
        setLocationRelativeTo(null);
        setLayout(null);


        setIconImage(icono.getImage());


        add(new PanelMenu());


    }
    public static Dimension getDimension(){
        Dimension dimension1 = new Dimension(700,700);
        return dimension1;
    }
    public void cambiarPanel(JPanel panelCambio){
        frame.setContentPane(panelCambio);
        frame.revalidate();
        frame.repaint();

    }




}
