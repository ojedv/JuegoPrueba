package clases;
import javax.swing.*;
import java.awt.*;
import java.util.jar.JarFile;

public class Frame extends JFrame {
    ImageIcon icono = new ImageIcon(getClass().getResource("./../imagenes/EpiFotoBuena.jpg"));
    static Frame frame;
    JPanel panelaux;


    public Frame(){
        frame = this;
        setVisible(true);
        setSize(getDimension());
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setIconImage(icono.getImage());

        panelaux = new PanelMenu();
        add(panelaux);


    }
    public static Dimension getDimension(){
        Dimension dimension1 = new Dimension(700,700);
        return dimension1;
    }
    public void cambiarPanel(JPanel panelCambio){
        frame.setContentPane(panelCambio);
        panelCambio.requestFocusInWindow();  // Solicitar el foco al nuevo panel
        frame.revalidate();
        frame.repaint();

    }




}
