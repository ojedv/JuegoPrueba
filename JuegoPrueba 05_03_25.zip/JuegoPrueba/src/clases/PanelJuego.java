package clases;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import static clases.Frame.frame;

public class PanelJuego extends JPanel implements ActionListener, KeyListener {
    JButton boton4 = new JButton("Volver al menu principal");
    Personaje protagonista;
    private Personaje personaje;
    private Timer timer;


    public PanelJuego(){
        setVisible(true);
        setBackground(Color.green);
        setSize(Frame.getDimension());
        setLayout(null);

        setFocusable(true);


        boton4.setBackground(new Color(230,230,230));
        boton4.setBounds(300,150,100,50);
        boton4.setBackground(new Color(233,233,233));
        boton4.addActionListener(this);
        boton4.setFocusable(false);
        add(boton4);

        personaje = new Personaje(new Posicion(100,100));
        timer = new Timer(200, this);
        timer.start();

        addKeyListener(this);
        requestFocusInWindow();

    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == boton4){
            frame.cambiarPanel(new PanelMenu());
            timer.stop(); // <-- Detiene el Timer al salir del juego
        } else if (e.getSource() == timer) {
            personaje.siguienteSprite(); // Cambia el sprite SIEMPRE, en loop
            repaint(); // Redibuja la pantalla
        }
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        personaje.dibujar(g);
    }


    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        // Detectar las teclas presionadas
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W: // W - Mover hacia arriba
                personaje.setPosition(0, -10); // Mover hacia arriba (resta en Y)
                break;
            case KeyEvent.VK_A: // A - Mover hacia la izquierda
                personaje.setPosition(-10, 0); // Mover hacia la izquierda (resta en X)
                break;
            case KeyEvent.VK_S: // S - Mover hacia abajo
                personaje.setPosition(0, 10); // Mover hacia abajo (suma en Y)
                break;
            case KeyEvent.VK_D: // D - Mover hacia la derecha
                personaje.setPosition(10, 0); // Mover hacia la derecha (suma en X)
                break;
        }
        repaint(); // Redibuja el personaje en la nueva posición
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }
}
