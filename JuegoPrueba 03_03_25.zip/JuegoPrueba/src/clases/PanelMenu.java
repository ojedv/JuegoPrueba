package clases;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static clases.Frame.frame;

public class PanelMenu extends JPanel implements ActionListener {
    private JButton boton1 = new JButton("Jugar");
    private JButton boton2 = new JButton("Opciones");
    private JButton boton3 = new JButton("Salir");
    private ImageIcon imagenfondo;

    public PanelMenu(){
        setVisible(true);
        setSize(Frame.getDimension());
        setLayout(null);

        this.imagenfondo = new ImageIcon(getClass().getResource("./../imagenes/FondoMenu.jpg"));



        boton1.setBackground(new Color(230,230,230));
        boton1.setBounds(300,150,100,50);
        boton1.setBackground(new Color(233,233,233));
        boton1.addActionListener(this);
        add(boton1);

        boton2.setBackground(new Color(230,230,230));
        boton2.setBounds(300,250,100,50);
        boton2.setBackground(new Color(233,233,233));
        boton2.addActionListener(this);
        add(boton2);

        boton3.setBackground(new Color(230,230,230));
        boton3.setBounds(300,350,100,50);
        boton3.setBackground(new Color(233,233,233));
        boton3.addActionListener(this);
        add(boton3);

        repaint();

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == boton1){
           frame.cambiarPanel(new PanelJuego());
        }else if(e.getSource() == boton2){

        }else if(e.getSource() == boton3){

        }

    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(imagenfondo.getImage(), 0, 0, this);

    }




}
