package clases;

import javax.swing.*;

public class Personaje {
    Posicion position;
    ImageIcon fotopj;
    public Personaje(Posicion par1,ImageIcon par2){
        this.position = par1;
        this.fotopj = par2;
    }
}
