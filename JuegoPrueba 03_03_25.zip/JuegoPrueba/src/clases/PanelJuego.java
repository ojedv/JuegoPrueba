package clases;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static clases.Frame.frame;

public class PanelJuego extends JPanel implements ActionListener {
    JButton boton4 = new JButton("Volver al menu principal");
    Personaje protagonista;

    public PanelJuego(){
        setVisible(true);
        setBackground(Color.green);
        setSize(Frame.getDimension());
        setLayout(null);


        boton4.setBackground(new Color(230,230,230));
        boton4.setBounds(300,150,100,50);
        boton4.setBackground(new Color(233,233,233));
        boton4.addActionListener(this);
        add(boton4);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == boton4){
            frame.cambiarPanel(new PanelMenu());
        }
    }


}
