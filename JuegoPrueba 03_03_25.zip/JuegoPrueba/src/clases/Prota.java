package clases;

import javax.swing.*;

public class Prota extends Personaje{
    public Prota(Posicion par1, ImageIcon par2) {
        super(par1, par2);
    }
    public Prota (ImageIcon par1){
        super(new Posicion(),par1);
    }
}
