package clases;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static clases.Frame.frame;

public class ElegirPersonaje extends JPanel implements ActionListener {
    JButton boton1;
    JButton boton2;
    JLabel elige;



    public ElegirPersonaje(){
        setVisible(true);
        setBackground(new Color(255, 238, 134));
        setSize(Frame.getDimension());
        setLayout(null);

        elige = new JLabel();

        boton1 = new JButton("Ocar");
        boton1.setBackground(new Color(230,230,230));
        boton1.setBounds(255,540,300,150);
        boton1.setBackground(new Color(220,220,220));
        boton1.setFont(new Font("Garamond", Font.BOLD, 40));
        add(boton1);

        boton2 = new JButton("Pajaroto");
        boton2.setBackground(new Color(230,230,230));
        boton2.setBounds(700,540,300,150);
        boton2.setBackground(new Color(220,220,220));
        boton2.setFont(new Font("Garamond", Font.BOLD, 40));
        add(boton2);

        boton1.addActionListener(this);
        boton2.addActionListener(this);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            Personaje Oscar = new Personaje(new Posicion(100,100),"/imagenes/OscarBasura000.png", "/imagenes/OscarBasura001.png", "/imagenes/OscarBasura002.png");
            frame.cambiarPanel(new PanelJuego(Oscar));
        } else if (e.getSource() == boton2) {
            Personaje Pajaroto = new Personaje(new Posicion(100,100),"/imagenes/Pajaroto000.png", "/imagenes/Pajaroto001.png", "/imagenes/Pajaroto002.png");
            frame.cambiarPanel(new PanelJuego(Pajaroto));
        }
    }
}
