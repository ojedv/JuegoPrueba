package clases;

import javax.swing.*;
import java.awt.*;

public class Personaje {
    Posicion position;
    public Image[] sprites;
    public int indiceSprite = 0;

    public Personaje(Posicion par1, String ruta1, String ruta2, String ruta3){
        this.position = par1;
        sprites = new Image[]{
                new ImageIcon(getClass().getResource(ruta1)).getImage(),
                new ImageIcon(getClass().getResource(ruta2)).getImage(),
                new ImageIcon(getClass().getResource(ruta3)).getImage()
        };
    }
    public Personaje(Posicion par1){
        this.position = par1;
        sprites = new Image[]{
                new ImageIcon(getClass().getResource("/imagenes/Pajaroto000.png")).getImage(),
                new ImageIcon(getClass().getResource("/imagenes/Pajaroto001.png")).getImage(),
                new ImageIcon(getClass().getResource("/imagenes/Pajaroto002.png")).getImage()
        };
    }

    public void dibujar(Graphics g) {
        g.drawImage(sprites[indiceSprite], position.getX(), position.getY(), 50, 80, null);
    }
    public void siguienteSprite() {
        indiceSprite = indiceSprite + 1;
        if(indiceSprite > 2){
            indiceSprite = 0;
        }
    }

    public Posicion getPosicion() {
        return position;
    }
    public void setPosition(int dx, int dy) {
        position.setX(position.getX() + dx);
        position.setY(position.getY() + dy);
    }
}
