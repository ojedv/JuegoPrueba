    package clases;

    import javax.swing.*;
    import java.awt.*;
    import java.awt.event.ActionEvent;
    import java.awt.event.ActionListener;
    import java.awt.event.KeyEvent;
    import java.awt.event.KeyListener;

    import static clases.Frame.frame;

    public class PanelJuego extends JPanel implements KeyListener {
        Personaje protagonista;
        JLabel volverMenu = new JLabel("ESC para volver al menu");
        private Personaje pers;
        private Timer timer;

        public PanelJuego(Personaje personaje){
            setVisible(true);
            setBackground(new Color(255, 238, 134));
            setSize(Frame.getDimension());
            setLayout(null);

            //Hace que al añadir otros elementos, estos no pillen el foco para los listeners
            setFocusTraversalKeysEnabled(false);

            volverMenu.setVisible(true);
            volverMenu.setBounds(20, 20, 400, 30);
            volverMenu.setForeground(Color.BLACK);
            add(volverMenu);
            volverMenu.setFont(new Font("Arial", Font.BOLD, 20));

            this.pers = personaje;

            timer = new Timer(100, new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    pers.siguienteSprite();
                    repaint();
                }
            });
            timer.start();

            addKeyListener(this);
            setFocusable(true);
            requestFocusInWindow();

        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (pers != null) {
                pers.dibujar(g);
            }
        }


        @Override
        public void keyTyped(KeyEvent e) {

        }

        @Override
        public void keyPressed(KeyEvent e) {
            if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                timer.stop();  // Detiene la animación antes de cambiar
                frame.cambiarPanel(new PanelMenu());
            }
            switch (e.getKeyCode()) {
                case KeyEvent.VK_W: // W - Mover hacia arriba
                    pers.setPosition(0, -10); // Mover hacia arriba (resta en Y)
                    break;
                case KeyEvent.VK_A: // A - Mover hacia la izquierda
                    pers.setPosition(-10, 0); // Mover hacia la izquierda (resta en X)
                    break;
                case KeyEvent.VK_S: // S - Mover hacia abajo
                    pers.setPosition(0, 10); // Mover hacia abajo (suma en Y)
                    break;
                case KeyEvent.VK_D: // D - Mover hacia la derecha
                    pers.setPosition(10, 0); // Mover hacia la derecha (suma en X)
                    break;
            }
            repaint(); // Redibuja el personaje en la nueva posición
        }

        @Override
        public void keyReleased(KeyEvent e) {

        }
    }
