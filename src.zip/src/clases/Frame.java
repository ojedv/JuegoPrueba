package clases;

import javax.swing.*;
import java.awt.*;

public class Frame extends JFrame {
    ImageIcon icono = new ImageIcon(getClass().getResource("/imagenes/EpiFotoBuena.jpg"));
    static Frame frame;
    JPanel panelaux;


    public Frame(){
        frame = this;
        setVisible(true);
        setSize(getDimension());
        setLocationRelativeTo(null);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setIconImage(icono.getImage());

        panelaux = new PanelMenu();
        add(panelaux);


    }
    public static Dimension getDimension(){
        Dimension dimension1 = new Dimension(1200,800);
        return dimension1;
    }
    public void cambiarPanel(JPanel panelCambio){
        frame.setContentPane(panelCambio);
        frame.revalidate();
        frame.repaint();
        panelCambio.requestFocusInWindow();

    }




}
