package clases;

import javax.swing.*;
import java.awt.*;

public class Personaje {
    Posicion position;
    public Image[] sprites;
    public int indiceSprite = 0;

    public Personaje(Posicion par1){
        this.position = par1;
        sprites = new Image[]{
                new ImageIcon(getClass().getResource("/imagenes/OscarBasura000.png")).getImage(),
                new ImageIcon(getClass().getResource("/imagenes/OscarBasura001.png")).getImage(),
                new ImageIcon(getClass().getResource("/imagenes/OscarBasura002.png")).getImage()
        };
    }
    public void dibujar(Graphics g) {
        g.drawImage(sprites[indiceSprite], position.getX(), position.getY(), 50, 80, null);
    }
    public void siguienteSprite() {
        indiceSprite = (indiceSprite + 1) % sprites.length; // Loop entre 0, 1, 2, 0...
    }

    public Posicion getPosicion() {
        return position;
    }
    public void setPosition(int dx, int dy) {
        position.setX(position.getX() + dx);
        position.setY(position.getY() + dy);
    }
}
