package clases;

import javax.sound.sampled.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import static clases.Frame.frame;

public class PanelMenu extends JPanel implements ActionListener {
    private JButton boton1 = new JButton("Jugar");
    private JButton boton2 = new JButton("Opciones");
    private JButton boton3 = new JButton("Salir");
    private ImageIcon imagenfondo;
    private Clip clipFondo;  // Clip para el sonido de fondo
    private Clip clipClick;


    public PanelMenu(){
        setVisible(true);
        setSize(Frame.getDimension());
        setLayout(null);
        frame.setResizable(false);

        this.imagenfondo = new ImageIcon(getClass().getResource("./../imagenes/BarrioSesamo2Buena.jpg"));



        reproducirSonidoFondo("/sonidos/tonobarriosesano.wav");

        boton1.setBackground(new Color(230,230,230));
        boton1.setBounds(255,540,300,150);
        boton1.setBackground(new Color(220,220,220));
        boton1.addActionListener(this);
        boton1.setFont(new Font("Garamond", Font.BOLD, 40));
        add(boton1);

        boton2.setBackground(new Color(230,230,230));
        boton2.setBounds(810,540,300,150);
        boton2.setBackground(new Color(220,220,220));
        boton2.addActionListener(this);
        boton2.setFont(new Font("Garamond", Font.BOLD, 40));
        add(boton2);

        boton3.setBackground(new Color(230,230,230));
        boton3.setBounds(1365,540,300,150);
        boton3.setBackground(new Color(220,220,220));
        boton3.addActionListener(this);
        boton3.setFont(new Font("Garamond", Font.BOLD, 40));
        add(boton3);


    }
    public void reproducirSonidoFondo(String rutaArchivo) {
        try {
            // Cargar y reproducir el nuevo sonido de fondo
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(getClass().getResource(rutaArchivo));
            clipFondo = AudioSystem.getClip();
            clipFondo.open(audioStream);
            clipFondo.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public void reproducirSonidoClick(String rutaArchivo) {
        try {
            // Obtener el archivo de sonido
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(getClass().getResource(rutaArchivo));
            clipClick = AudioSystem.getClip();
            clipClick.open(audioStream);

            // Reproducir el sonido
            clipClick.start();
        } catch (Exception e) {
            e.printStackTrace(); // Aunque prefieras no usar try-catch, es necesario en este caso
        }
    }
    public void detenerSonidoFondo() {
        if (clipFondo != null) {
            clipFondo.stop();
            clipFondo.close();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == boton1){
            reproducirSonidoClick("/sonidos/MouseClick.wav");
            frame.cambiarPanel(new PanelJuego());
            detenerSonidoFondo();
        }else if(e.getSource() == boton2){
            reproducirSonidoClick("/sonidos/MouseClick.wav");
            detenerSonidoFondo();
        }else if(e.getSource() == boton3){
            reproducirSonidoClick("/sonidos/MouseClick.wav");
            frame.dispose();
        }

    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(imagenfondo.getImage(), 0, 0, this);

    }




}
